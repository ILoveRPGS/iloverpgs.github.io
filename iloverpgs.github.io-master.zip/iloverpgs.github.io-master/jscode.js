let mina = prompt ("Anna nimesi: ")

if (mina == "Mitja"){
     console.log("Welcome Onii-chan")
}
else if (mina == "Sardor"){ 
     console.log("What are u doing here u bastard!!")
}
else console.log("Youre not welcome");